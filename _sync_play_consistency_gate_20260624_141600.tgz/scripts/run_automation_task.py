"""Run one automation-center task in an isolated subprocess."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

DEFAULT_DB = ROOT / "data" / "football_v2.db"
DEFAULT_ODDSFE_DB = (
    ROOT / "data" / "oddsfe_merged.db"
    if (ROOT / "data" / "oddsfe_merged.db").exists()
    else ROOT / "fetchers" / "odds_feed_api" / "oddsfe_merged.db"
)
SENTINEL = "AUTOMATION_TASK_JSON="


def emit(payload: Dict[str, Any]) -> None:
    print(SENTINEL + json.dumps(payload, ensure_ascii=False, default=str), flush=True)


def run_event_details(args: argparse.Namespace) -> Dict[str, Any]:
    from backend.app.lottery.services.oddsfe_event_sync import OddsfeEventDetailSync

    return OddsfeEventDetailSync(args.db).run(
        args.date_from,
        args.date_to,
        apply=True,
        refresh=False,
        fetch_schedule=True,
        include_schedule_only=True,
        max_events=args.max_events,
        schedule_padding_days=1,
        cache_minutes=12,
        sleep_seconds=0.12,
        trigger_source=f"{args.trigger_source}_event_details",
    )


def run_ou_lines(args: argparse.Namespace) -> Dict[str, Any]:
    from backend.app.lottery.services.oddsfe_ou_line_sync import OddsfeOuLineSync

    return OddsfeOuLineSync(args.db, args.oddsfe_db).run(
        args.date_from,
        args.date_to,
        apply=True,
        fetch_live=args.fetch_live_ou,
        max_events=args.max_events,
        reanalyze=False,
        trigger_source=f"{args.trigger_source}_ou_lines",
    )


def run_intelligence(args: argparse.Namespace) -> Dict[str, Any]:
    from backend.app.intelligence.service import IntelligenceService

    return IntelligenceService(args.db).fill_gaps_logged(
        start_date=args.date_from,
        end_date=args.date_to,
        collectors=["injuries_suspensions", "team_news", "expected_lineup", "weather"],
        network=args.network_intelligence,
        force=False,
        include_optional=True,
        include_builtin=True,
        limit=args.max_intelligence,
        trigger_source=f"{args.trigger_source}_intelligence",
    )


def run_analysis(args: argparse.Namespace) -> Dict[str, Any]:
    from backend.app.lottery.services.auto_gap_runner import LotteryAutoGapRunner
    from backend.app.core.analyze import analyze_single

    if args.force:
        import sqlite3

        conn = sqlite3.connect(args.db, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            where = [
                "substr(COALESCE(beijing_time, match_date), 1, 10) BETWEEN ? AND ?",
                "home_team_id IS NOT NULL",
                "away_team_id IS NOT NULL",
            ]
            params: list[Any] = [args.date_from, args.date_to]
            if args.league:
                where.append("COALESCE(league_name_cn, '') = ?")
                params.append(args.league)
            params.append(args.max_analysis)
            rows = conn.execute(
                f"""
                SELECT lottery_match_id
                FROM lottery_matches
                WHERE {' AND '.join(where)}
                ORDER BY substr(COALESCE(beijing_time, match_date), 1, 10), match_time, lottery_match_id
                LIMIT ?
                """,
                params,
            ).fetchall()
        finally:
            conn.close()

        analyzed = []
        failed = []
        for row in rows:
            match_id = str(row["lottery_match_id"])
            try:
                report = analyze_single(args.db, match_id)
                if report:
                    analyzed.append(match_id)
                else:
                    failed.append({"lottery_match_id": match_id, "error": "empty_report"})
            except Exception as exc:
                failed.append({"lottery_match_id": match_id, "error": str(exc)[:180]})
        return {
            "success": True,
            "forced": True,
            "targets": len(rows),
            "analyzed": len(analyzed),
            "failed": len(failed),
            "analyzed_ids": analyzed[:20],
            "failed_examples": failed[:8],
        }

    return LotteryAutoGapRunner(args.db, args.oddsfe_db)._analyze_missing_or_stale(
        args.date_from,
        args.date_to,
        limit=args.max_analysis,
        league=args.league or None,
    )


def run_result_audit(args: argparse.Namespace) -> Dict[str, Any]:
    from backend.app.lottery.services.result_consistency import run_result_consistency_audit

    return run_result_consistency_audit(
        args.db,
        args.date_from,
        args.date_to,
        apply=True,
        league=args.league or None,
        trigger_source=f"{args.trigger_source}_result_audit",
    )


def run_validation(args: argparse.Namespace) -> Dict[str, Any]:
    from backend.app.core.validate import _validate_predictions
    from backend.app.lottery.services.auto_gap_runner import LotteryAutoGapRunner, date_list

    dates = date_list(args.date_from, args.date_to)[: args.max_validation_dates]
    result = _validate_predictions(args.db, dates)
    result["queued_revalidation"] = LotteryAutoGapRunner(args.db, args.oddsfe_db)._mark_revalidation_processed(dates)
    return result


def run_learning(args: argparse.Namespace) -> Dict[str, Any]:
    from backend.app.lottery.services.auto_gap_runner import LotteryAutoGapRunner

    return LotteryAutoGapRunner(args.db, args.oddsfe_db)._refresh_learning(
        args.date_from,
        args.date_to,
        league=args.league or None,
    )


def _national_ou_args(args: argparse.Namespace, *, apply: bool, refresh_notes: bool = False) -> argparse.Namespace:
    return argparse.Namespace(
        db=args.db,
        fact_table=args.national_ou_fact_table,
        date_from=args.date_from,
        date_to=args.date_to,
        league=args.league or "世界杯",
        report_type=args.national_ou_report_type,
        limit=args.national_ou_limit,
        min_sample=args.national_ou_min_sample,
        band=args.national_ou_band,
        apply=apply,
        rollback_on_worse=True,
        rebuild_validation=args.national_ou_rebuild_validation,
        refresh_notes=refresh_notes,
        examples_limit=args.national_ou_examples_limit,
    )


def _compact_national_ou_result(result: Dict[str, Any], *, skipped: bool = False, reason: str = "") -> Dict[str, Any]:
    summary = result.get("summary") if isinstance(result.get("summary"), dict) else {}
    apply_result = result.get("apply_result") if isinstance(result.get("apply_result"), dict) else {}
    validation = result.get("validation_result") if isinstance(result.get("validation_result"), dict) else {}
    payload = {
        "success": result.get("success", True),
        "skipped": skipped,
        "reason": reason or result.get("abort_reason") or result.get("reason"),
        "accepted": result.get("accepted"),
        "fact_table": result.get("fact_table"),
        "reports_checked": result.get("reports_checked"),
        "changes": int(summary.get("changes") or 0),
        "improved": int(summary.get("improved") or 0),
        "regressed": int(summary.get("regressed") or 0),
        "metadata_only": int(summary.get("metadata_only") or 0),
        "scored": int(summary.get("scored") or 0),
        "before_correct": int(summary.get("before_correct") or 0),
        "after_correct": int(summary.get("after_correct") or 0),
        "delta_correct": int(summary.get("delta_correct") or 0),
        "changed_reports": int(apply_result.get("reports") or 0),
        "prediction_rows": int(apply_result.get("prediction_rows") or 0),
        "backup_path": result.get("backup_path"),
        "changed_dates": result.get("changed_dates") or [],
        "validated": int(validation.get("validated") or 0),
        "validation_accuracy": validation.get("accuracy"),
    }
    return {key: value for key, value in payload.items() if value not in (None, "", [])}


def run_national_ou_gate(args: argparse.Namespace) -> Dict[str, Any]:
    from scripts.apply_national_ou_conflict_gate import connect, run as run_gate, table_exists

    with connect(Path(args.db)) as conn:
        if not table_exists(conn, args.national_ou_fact_table):
            return {
                "success": True,
                "skipped": True,
                "reason": "national_reference_fact_table_missing",
                "fact_table": args.national_ou_fact_table,
            }

    dry_result = run_gate(_national_ou_args(args, apply=False))
    dry_summary = dry_result.get("summary") if isinstance(dry_result.get("summary"), dict) else {}
    if int(dry_summary.get("changes") or 0) <= 0:
        return _compact_national_ou_result(dry_result, skipped=True, reason="no_eligible_ou_conflicts")
    if int(dry_summary.get("delta_correct") or 0) < 0:
        return _compact_national_ou_result(dry_result, skipped=True, reason="dry_run_delta_worse")

    apply_result = run_gate(_national_ou_args(args, apply=True))
    compact = _compact_national_ou_result(apply_result)
    compact["dry_run"] = {
        "changes": int(dry_summary.get("changes") or 0),
        "improved": int(dry_summary.get("improved") or 0),
        "regressed": int(dry_summary.get("regressed") or 0),
        "delta_correct": int(dry_summary.get("delta_correct") or 0),
    }
    return compact


def _play_consistency_args(args: argparse.Namespace, *, apply: bool) -> argparse.Namespace:
    return argparse.Namespace(
        db=args.db,
        date_from=args.date_from,
        date_to=args.date_to,
        league=args.league or "世界杯",
        report_type=args.play_consistency_report_type,
        apply=apply,
        rollback_on_worse=True,
        rebuild_validation=args.play_consistency_rebuild_validation,
        examples_limit=args.play_consistency_examples_limit,
    )


def _compact_play_consistency_result(result: Dict[str, Any], *, skipped: bool = False, reason: str = "") -> Dict[str, Any]:
    summary = result.get("summary") if isinstance(result.get("summary"), dict) else {}
    apply_result = result.get("apply_result") if isinstance(result.get("apply_result"), dict) else {}
    validation = result.get("validation_result") if isinstance(result.get("validation_result"), dict) else {}
    return {
        "success": result.get("success", True),
        "skipped": skipped,
        "reason": reason or result.get("abort_reason") or result.get("reason"),
        "accepted": result.get("accepted"),
        "reports_checked": result.get("reports_checked"),
        "changes": int(summary.get("changes") or 0),
        "changed_reports": int(apply_result.get("reports") or 0),
        "prediction_rows": int(apply_result.get("prediction_rows") or 0),
        "improved": int(summary.get("improved") or 0),
        "regressed": int(summary.get("regressed") or 0),
        "scored": int(summary.get("scored") or 0),
        "before_correct": int(summary.get("before_correct") or 0),
        "after_correct": int(summary.get("after_correct") or 0),
        "delta_correct": int(summary.get("delta_correct") or 0),
        "by_play_type": summary.get("by_play_type") or {},
        "backup_path": result.get("backup_path"),
        "changed_dates": result.get("changed_dates") or [],
        "validated": int(validation.get("validated") or 0),
        "validation_accuracy": validation.get("accuracy"),
    }


def run_play_consistency_gate(args: argparse.Namespace) -> Dict[str, Any]:
    from scripts.apply_play_consistency_gate import run as run_gate

    dry_result = run_gate(_play_consistency_args(args, apply=False))
    dry_summary = dry_result.get("summary") if isinstance(dry_result.get("summary"), dict) else {}
    if int(dry_summary.get("changes") or 0) <= 0:
        return _compact_play_consistency_result(dry_result, skipped=True, reason="no_hard_play_conflicts")
    if int(dry_summary.get("delta_correct") or 0) < 0:
        return _compact_play_consistency_result(dry_result, skipped=True, reason="dry_run_delta_worse")

    apply_result = run_gate(_play_consistency_args(args, apply=True))
    compact = _compact_play_consistency_result(apply_result)
    compact["dry_run"] = {
        "changes": int(dry_summary.get("changes") or 0),
        "improved": int(dry_summary.get("improved") or 0),
        "regressed": int(dry_summary.get("regressed") or 0),
        "delta_correct": int(dry_summary.get("delta_correct") or 0),
    }
    return compact


TASKS = {
    "event_details": run_event_details,
    "ou_lines": run_ou_lines,
    "intelligence": run_intelligence,
    "result_audit": run_result_audit,
    "analysis": run_analysis,
    "play_consistency_gate": run_play_consistency_gate,
    "validation": run_validation,
    "national_ou_gate": run_national_ou_gate,
    "learning": run_learning,
}


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", choices=sorted(TASKS), required=True)
    parser.add_argument("--db", default=str(DEFAULT_DB))
    parser.add_argument("--oddsfe-db", default=str(DEFAULT_ODDSFE_DB))
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--league", default="")
    parser.add_argument("--max-events", type=int, default=6)
    parser.add_argument("--max-analysis", type=int, default=10)
    parser.add_argument("--max-intelligence", type=int, default=6)
    parser.add_argument("--max-validation-dates", type=int, default=1)
    parser.add_argument("--fetch-live-ou", action="store_true")
    parser.add_argument("--network-intelligence", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--trigger-source", default="automation_center")
    parser.add_argument("--national-ou-fact-table", default=os.environ.get("FOOTBALL_NATIONAL_REFERENCE_FACT_TABLE", "team_match_facts"))
    parser.add_argument("--national-ou-report-type", default="prediction")
    parser.add_argument("--national-ou-limit", type=int, default=20)
    parser.add_argument("--national-ou-min-sample", type=int, default=16)
    parser.add_argument("--national-ou-band", type=float, default=0.25)
    parser.add_argument("--national-ou-examples-limit", type=int, default=8)
    parser.add_argument("--no-national-ou-rebuild-validation", dest="national_ou_rebuild_validation", action="store_false", default=True)
    parser.add_argument("--play-consistency-report-type", default="prediction")
    parser.add_argument("--play-consistency-examples-limit", type=int, default=8)
    parser.add_argument("--no-play-consistency-rebuild-validation", dest="play_consistency_rebuild_validation", action="store_false", default=True)
    return parser.parse_args(argv)


def main() -> int:
    args = parse_args()
    try:
        payload = TASKS[args.task](args)
        if payload is None:
            payload = {}
        payload = {"success": payload.get("success", True), "task": args.task, **payload}
        emit(payload)
        return 0 if payload.get("success") is not False else 1
    except Exception as exc:
        emit({"success": False, "task": args.task, "error": str(exc)})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
