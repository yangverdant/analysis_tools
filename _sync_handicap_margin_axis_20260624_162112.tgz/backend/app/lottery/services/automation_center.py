"""Parallel automation center for lottery data work.

The center is intentionally a coordinator, not another analyzer. It splits work
into small dated tasks, runs safe independent tasks concurrently, records every
task result, and keeps later waves moving even when one task fails.
"""

from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union

from backend.app.data_access.foundation_dao import FoundationDAO
from backend.app.lottery.services.auto_gap_runner import LotteryAutoGapRunner, date_list


ROOT = Path(__file__).resolve().parents[4]
DEFAULT_DB = ROOT / "data" / "football_v2.db"
DEFAULT_ODDSFE_DB = (
    ROOT / "data" / "oddsfe_merged.db"
    if (ROOT / "data" / "oddsfe_merged.db").exists()
    else ROOT / "fetchers" / "odds_feed_api" / "oddsfe_merged.db"
)
TASK_SENTINEL = "AUTOMATION_TASK_JSON="


@dataclass(frozen=True)
class AutomationTask:
    kind: str
    date_from: str
    date_to: str
    wave: int
    reason: str
    action_counts: Dict[str, int]

    @property
    def match_date(self) -> str:
        return self.date_from

    @property
    def key(self) -> str:
        return f"{self.wave}:{self.kind}:{self.date_from}:{self.date_to}"


def _today() -> datetime.date:
    return datetime.now().date()


def _date_values(date_from: str, date_to: str) -> List[str]:
    return date_list(date_from, date_to)


def _has_action(actions: Dict[str, int], *names: str) -> bool:
    return any(int(actions.get(name) or 0) > 0 for name in names)


def _compact_actions(actions: Dict[str, int]) -> Dict[str, int]:
    return {key: int(value or 0) for key, value in sorted(actions.items()) if int(value or 0) > 0}


def _merge_actions(target: Dict[str, int], source: Dict[str, int]) -> None:
    for key, value in (source or {}).items():
        try:
            amount = int(value or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount > 0:
            target[key] = int(target.get(key) or 0) + amount


def _parse_task_payload(output: str) -> Dict[str, Any]:
    for line in reversed((output or "").splitlines()):
        if line.startswith(TASK_SENTINEL):
            try:
                return json.loads(line[len(TASK_SENTINEL):])
            except Exception as exc:
                return {"success": False, "parse_error": str(exc), "raw": line[-2000:]}
    return {"success": False, "parse_error": "task JSON sentinel not found", "raw_tail": (output or "")[-4000:]}


class AutomationCenter:
    """A small task coordinator with bounded subprocess workers."""

    def __init__(self, db_path: Union[str, Path] = DEFAULT_DB, oddsfe_db_path: Union[str, Path] = DEFAULT_ODDSFE_DB):
        self.db_path = str(db_path)
        self.oddsfe_db_path = str(oddsfe_db_path)
        self.foundation = FoundationDAO(self.db_path)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def _table_exists(self, table_name: str) -> bool:
        with self._connect() as conn:
            return conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?",
                (table_name,),
            ).fetchone() is not None

    def _default_national_ou_fact_table(self) -> str:
        configured = os.environ.get("FOOTBALL_NATIONAL_REFERENCE_FACT_TABLE")
        if configured:
            return configured
        candidate = "team_match_facts_candidate_full_20260624"
        return candidate if self._table_exists(candidate) else "team_match_facts"

    def _default_bqc_profile_fact_table(self) -> str:
        configured = os.environ.get("FOOTBALL_BQC_PROFILE_FACT_TABLE")
        if configured:
            return configured
        candidate = "team_match_facts_candidate_full_20260624"
        return candidate if self._table_exists(candidate) else "team_match_facts"

    def _distinct_match_dates(self, date_from: str, date_to: str, league: str = "") -> List[str]:
        where = ["substr(COALESCE(beijing_time, match_date), 1, 10) BETWEEN ? AND ?"]
        params: List[Any] = [date_from, date_to]
        if league:
            where.append("COALESCE(league_name_cn, '') = ?")
            params.append(league)
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT DISTINCT substr(COALESCE(beijing_time, match_date), 1, 10) AS d
                FROM lottery_matches
                WHERE {' AND '.join(where)}
                ORDER BY d
                """,
                params,
            ).fetchall()
        return [str(row["d"]) for row in rows if row["d"]]

    def _match_ids_for_dates(self, date_values: Sequence[str], league: str = "") -> List[str]:
        if not date_values:
            return []
        placeholders = ",".join("?" for _ in date_values)
        where = [
            f"substr(COALESCE(beijing_time, match_date), 1, 10) IN ({placeholders})",
            "home_team_id IS NOT NULL",
            "away_team_id IS NOT NULL",
        ]
        params: List[Any] = list(date_values)
        if league:
            where.append("COALESCE(league_name_cn, '') = ?")
            params.append(league)
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT lottery_match_id
                FROM lottery_matches
                WHERE {' AND '.join(where)}
                ORDER BY substr(COALESCE(beijing_time, match_date), 1, 10), lottery_match_id
                """,
                params,
            ).fetchall()
        return [str(row["lottery_match_id"]) for row in rows]

    def _backup_force_targets(self, date_values: Sequence[str], league: str) -> Optional[str]:
        match_ids = self._match_ids_for_dates(date_values, league=league)
        if not match_ids:
            return None
        from scripts.run_model_reanalysis_stage import backup_analysis_layer, connect

        tag = f"automation_center_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        conn = connect(Path(self.db_path))
        try:
            path = backup_analysis_layer(Path(self.db_path), conn, match_ids, date_values, tag)
        finally:
            conn.close()
        return str(path)

    def _mark_duplicate_reports_stale(self) -> Dict[str, Any]:
        try:
            from scripts.mark_duplicate_reports_stale import mark_duplicate_reports_stale

            return mark_duplicate_reports_stale(Path(self.db_path), include_full=True, apply=True)
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def _model_change_gate(self, backup_path: Optional[str], date_values: Sequence[str], league: str) -> Optional[Dict[str, Any]]:
        if not backup_path:
            return None
        try:
            from scripts.model_change_gate import evaluate_model_change

            return evaluate_model_change(
                db_path=Path(self.db_path),
                backup_path=Path(backup_path),
                date_from=min(date_values) if date_values else "",
                date_to=max(date_values) if date_values else "",
                league=league,
                overall_drop_tolerance_pp=1.0,
                play_drop_tolerance_pp=3.0,
                fail_on_missing=True,
                limit=20,
            )
        except Exception as exc:
            return {"success": False, "decision": "fail", "error": str(exc)}

    def _restore_analysis_backup(self, backup_path: Optional[str]) -> Optional[Dict[str, Any]]:
        if not backup_path:
            return None
        try:
            from scripts.run_model_reanalysis_stage import restore_backup

            restored = restore_backup(Path(self.db_path), Path(backup_path))
            return {"success": True, "backup": backup_path, **restored}
        except Exception as exc:
            return {"success": False, "backup": backup_path, "error": str(exc)}

    def _historical_candidates(
        self,
        *,
        latest_offset_days: int,
        lookback_days: int,
        max_dates: int,
        league: str,
    ) -> List[str]:
        latest = _today() - timedelta(days=max(latest_offset_days, 0))
        earliest = latest - timedelta(days=max(lookback_days, 1))
        dates = list(reversed(self._distinct_match_dates(earliest.isoformat(), latest.isoformat(), league)))
        runner = LotteryAutoGapRunner(self.db_path, self.oddsfe_db_path)
        selected: List[str] = []
        for value in dates:
            actions = _compact_actions(runner.infer_action_counts(value, value, league=league or None))
            if actions:
                selected.append(value)
            if len(selected) >= max_dates:
                break
        return selected

    def resolve_dates(
        self,
        *,
        mode: str,
        date_from: Optional[str],
        date_to: Optional[str],
        league: str = "",
        historical_dates: int = 0,
        historical_lookback_days: int = 180,
        historical_latest_offset_days: int = 1,
    ) -> List[str]:
        mode = (mode or "rolling").strip().lower()
        values: List[str] = []
        if mode in {"rolling", "mixed"}:
            today = _today()
            values.extend((today + timedelta(days=offset)).isoformat() for offset in (-1, 0, 1, 2))
        if mode == "range":
            if not date_from or not date_to:
                raise ValueError("date_from/date_to are required for range mode")
            values.extend(_date_values(date_from, date_to))
        if mode == "mixed" and date_from and date_to:
            values.extend(_date_values(date_from, date_to))
        if mode == "historical" or (mode == "mixed" and historical_dates > 0):
            values.extend(
                self._historical_candidates(
                    latest_offset_days=historical_latest_offset_days,
                    lookback_days=historical_lookback_days,
                    max_dates=max(historical_dates, 1),
                    league=league,
                )
            )
        if mode not in {"rolling", "range", "historical", "mixed"}:
            raise ValueError(f"unsupported automation mode: {mode}")
        return sorted(set(values))

    def build_tasks(
        self,
        date_values: Sequence[str],
        *,
        league: str = "",
        include_learning: bool = True,
        national_ou_gate: bool = True,
        force_analysis: bool = False,
        force_validation: bool = False,
        force_learning: bool = False,
    ) -> List[AutomationTask]:
        runner = LotteryAutoGapRunner(self.db_path, self.oddsfe_db_path)
        tasks: List[AutomationTask] = []
        needs_learning = False
        learning_actions: Dict[str, int] = {}

        for value in sorted(set(date_values)):
            actions = _compact_actions(runner.infer_action_counts(value, value, league=league or None))
            if not actions and not (force_analysis or force_validation):
                continue
            if _has_action(actions, "sync_event_detail", "collect_odds"):
                tasks.append(AutomationTask("event_details", value, value, 1, "event/result/odds gap", actions))
            if _has_action(actions, "sync_ou_line"):
                tasks.append(AutomationTask("ou_lines", value, value, 1, "true O/U line gap", actions))
            if _has_action(actions, "collect_intelligence"):
                tasks.append(AutomationTask("intelligence", value, value, 1, "intelligence gap", actions))
            if _has_action(actions, "audit_results", "sync_event_detail", "sync_ou_line"):
                tasks.append(AutomationTask("result_audit", value, value, 2, "settled result consistency audit", actions))
            if _has_action(actions, "analyze", "collect_intelligence", "sync_ou_line", "sync_event_detail", "collect_odds"):
                tasks.append(AutomationTask("analysis", value, value, 3, "analysis missing/stale or upstream changed", actions))
                needs_learning = True
                _merge_actions(learning_actions, actions)
            elif force_analysis:
                tasks.append(AutomationTask("analysis", value, value, 3, "forced model re-analysis", actions or {"force_analysis": 1}))
                needs_learning = True
                _merge_actions(learning_actions, actions or {"force_analysis": 1})
            if _has_action(actions, "analyze", "collect_intelligence", "sync_ou_line", "sync_event_detail", "collect_odds", "validate", "audit_results") or force_analysis or force_validation:
                tasks.append(
                    AutomationTask(
                        "play_consistency_gate",
                        value,
                        value,
                        5,
                        "hard SPF/RQSPF/BQC consistency gate",
                        actions or {"play_consistency_gate": 1},
                    )
                )
                needs_learning = True
                _merge_actions(learning_actions, {"play_consistency_gate": 1})
                tasks.append(
                    AutomationTask(
                        "bqc_full_axis_gate",
                        value,
                        value,
                        4,
                        "BQC full-time leg arbitration gate",
                        actions or {"bqc_full_axis_gate": 1},
                    )
                )
                needs_learning = True
                _merge_actions(learning_actions, {"bqc_full_axis_gate": 1})
            if _has_action(actions, "validate", "audit_results"):
                tasks.append(AutomationTask("validation", value, value, 6, "settled match validation gap", actions))
                needs_learning = True
                _merge_actions(learning_actions, actions)
            elif force_validation:
                tasks.append(AutomationTask("validation", value, value, 6, "forced validation rebuild", actions or {"force_validation": 1}))
                needs_learning = True
                _merge_actions(learning_actions, actions or {"force_validation": 1})
            if national_ou_gate and (_has_action(actions, "validate", "audit_results") or force_validation):
                tasks.append(
                    AutomationTask(
                        "national_ou_gate",
                        value,
                        value,
                        7,
                        "post-validation national-team O/U conflict gate",
                        actions or {"force_validation": 1},
                    )
                )
                needs_learning = True
                _merge_actions(learning_actions, {"national_ou_gate": 1})
            if _has_action(actions, "validate", "audit_results") or force_validation:
                tasks.append(
                    AutomationTask(
                        "bqc_half_time_profile",
                        value,
                        value,
                        8,
                        "post-validation BQC half-time profile audit",
                        actions or {"bqc_half_time_profile": 1},
                    )
                )
                needs_learning = True
                _merge_actions(learning_actions, {"bqc_half_time_profile": 1})
                tasks.append(
                    AutomationTask(
                        "prediction_error_review",
                        value,
                        value,
                        10,
                        "post-validation error attribution and next-action review",
                        actions or {"prediction_error_review": 1},
                    )
                )
                needs_learning = True
                _merge_actions(learning_actions, {"prediction_error_review": 1})
                tasks.append(
                    AutomationTask(
                        "bqc_full_time_axis",
                        value,
                        value,
                        9,
                        "post-validation BQC full-time axis audit",
                        actions or {"bqc_full_time_axis": 1},
                    )
                )
                needs_learning = True
                _merge_actions(learning_actions, {"bqc_full_time_axis": 1})
                tasks.append(
                    AutomationTask(
                        "handicap_margin_axis",
                        value,
                        value,
                        9,
                        "post-validation handicap margin boundary audit",
                        actions or {"handicap_margin_axis": 1},
                    )
                )
                needs_learning = True
                _merge_actions(learning_actions, {"handicap_margin_axis": 1})
            if _has_action(actions, "refresh_learning"):
                needs_learning = True
                _merge_actions(learning_actions, actions)
            elif _has_action(actions, "audit_results"):
                needs_learning = True

        if include_learning and (needs_learning or force_learning) and date_values:
            tasks.append(
                AutomationTask(
                    "learning",
                    min(date_values),
                    max(date_values),
                    11,
                    "single final learning refresh after dated tasks",
                    _compact_actions(learning_actions or {"refresh_learning": 1}),
                )
            )
        return tasks

    def plan(
        self,
        *,
        mode: str = "rolling",
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        league: str = "",
        historical_dates: int = 0,
        historical_lookback_days: int = 180,
        include_learning: bool = True,
        national_ou_gate: bool = True,
        force_analysis: bool = False,
        force_validation: bool = False,
        force_learning: bool = False,
    ) -> Dict[str, Any]:
        date_values = self.resolve_dates(
            mode=mode,
            date_from=date_from,
            date_to=date_to,
            league=league,
            historical_dates=historical_dates,
            historical_lookback_days=historical_lookback_days,
        )
        tasks = self.build_tasks(
            date_values,
            league=league,
            include_learning=include_learning,
            national_ou_gate=national_ou_gate,
            force_analysis=force_analysis,
            force_validation=force_validation,
            force_learning=force_learning,
        )
        by_wave: Dict[str, int] = {}
        by_kind: Dict[str, int] = {}
        for task in tasks:
            by_wave[str(task.wave)] = by_wave.get(str(task.wave), 0) + 1
            by_kind[task.kind] = by_kind.get(task.kind, 0) + 1
        return {
            "success": True,
            "mode": mode,
            "league": league,
            "dates": date_values,
            "task_count": len(tasks),
            "by_wave": by_wave,
            "by_kind": by_kind,
            "tasks": [asdict(task) for task in tasks],
        }

    def run(
        self,
        *,
        mode: str = "rolling",
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        league: str = "",
        historical_dates: int = 0,
        historical_lookback_days: int = 180,
        include_learning: bool = True,
        national_ou_gate: bool = True,
        national_ou_fact_table: Optional[str] = None,
        bqc_profile_fact_table: Optional[str] = None,
        force_analysis: bool = False,
        force_validation: bool = False,
        force_learning: bool = False,
        workers: int = 3,
        task_timeout_seconds: int = 300,
        max_events: int = 6,
        max_analysis: int = 10,
        max_intelligence: int = 6,
        max_validation_dates: int = 1,
        fetch_live_ou: bool = True,
        network_intelligence: bool = True,
        trigger_source: str = "automation_center",
    ) -> Dict[str, Any]:
        plan = self.plan(
            mode=mode,
            date_from=date_from,
            date_to=date_to,
            league=league,
            historical_dates=historical_dates,
            historical_lookback_days=historical_lookback_days,
            include_learning=include_learning,
            national_ou_gate=national_ou_gate,
            force_analysis=force_analysis,
            force_validation=force_validation,
            force_learning=force_learning,
        )
        national_ou_fact_table = national_ou_fact_table or self._default_national_ou_fact_table()
        bqc_profile_fact_table = bqc_profile_fact_table or self._default_bqc_profile_fact_table()
        tasks = [AutomationTask(**item) for item in plan["tasks"]]
        run_id = self.foundation.start_run(
            run_type="automation_center",
            match_date=plan["dates"][0] if plan["dates"] else None,
            trigger_source=trigger_source,
            summary={"stage": "start", **{key: plan[key] for key in ("mode", "league", "dates", "task_count", "by_wave", "by_kind")}},
        )
        summary: Dict[str, Any] = {
            **{key: plan[key] for key in ("mode", "league", "dates", "task_count", "by_wave", "by_kind")},
            "workers": max(1, int(workers)),
            "task_timeout_seconds": task_timeout_seconds,
            "waves": [],
            "tasks": [],
        }
        try:
            if not tasks:
                summary["report_stale_marking"] = self._mark_duplicate_reports_stale()
                summary["maintenance_failed"] = not bool((summary.get("report_stale_marking") or {}).get("success", True))
                summary["success"] = not summary["maintenance_failed"]
                summary["skipped"] = True
                summary["reason"] = "no actionable automation tasks"
                self.foundation.finish_run(
                    run_id,
                    status="success" if summary["success"] else "failed",
                    summary=summary,
                    error=None if summary["success"] else "report stale marking failed",
                )
                return {"success": summary["success"], "run_id": run_id, **summary}

            if force_analysis or force_validation or force_learning:
                summary["analysis_layer_backup"] = self._backup_force_targets(plan["dates"], league)

            for wave in sorted({task.wave for task in tasks}):
                wave_tasks = [task for task in tasks if task.wave == wave]
                wave_started = time.time()
                wave_result = {"wave": wave, "task_count": len(wave_tasks), "results": []}
                runnable_tasks: List[AutomationTask] = []
                for task in wave_tasks:
                    skip_reason = self._skip_task_reason(
                        task,
                        summary,
                        force=force_analysis or force_validation or force_learning,
                    )
                    if skip_reason:
                        result = self._skipped_task_result(task, skip_reason)
                        wave_result["results"].append(result)
                        summary["tasks"].append(result)
                    else:
                        runnable_tasks.append(task)

                if runnable_tasks:
                    with ThreadPoolExecutor(max_workers=max(1, int(workers)), thread_name_prefix=f"auto-wave-{wave}") as pool:
                        futures = {
                            pool.submit(
                                self._execute_task,
                                task,
                                timeout_seconds=task_timeout_seconds,
                                max_events=max_events,
                                max_analysis=max_analysis,
                                max_intelligence=max_intelligence,
                                max_validation_dates=max_validation_dates,
                                fetch_live_ou=fetch_live_ou,
                                network_intelligence=network_intelligence,
                                national_ou_fact_table=national_ou_fact_table,
                                bqc_profile_fact_table=bqc_profile_fact_table,
                                league=league,
                                trigger_source=trigger_source,
                                force=force_analysis or force_validation or force_learning,
                            ): task
                            for task in runnable_tasks
                        }
                        for future in as_completed(futures):
                            result = future.result()
                            wave_result["results"].append(result)
                            summary["tasks"].append(result)
                wave_result["elapsed_seconds"] = round(time.time() - wave_started, 1)
                wave_result["skipped"] = sum(1 for item in wave_result["results"] if item.get("skipped"))
                wave_result["failed"] = sum(1 for item in wave_result["results"] if not item.get("success"))
                summary["waves"].append(wave_result)

            summary["report_stale_marking"] = self._mark_duplicate_reports_stale()
            summary["model_gate"] = self._model_change_gate(summary.get("analysis_layer_backup"), plan["dates"], league)
            summary["failed_tasks"] = sum(1 for item in summary["tasks"] if not item.get("success"))
            summary["maintenance_failed"] = not bool((summary.get("report_stale_marking") or {}).get("success", True))
            summary["model_gate_failed"] = bool((summary.get("model_gate") or {}).get("decision") == "fail")
            if summary["model_gate_failed"]:
                summary["model_gate_rollback"] = self._restore_analysis_backup(summary.get("analysis_layer_backup"))
                summary["model_gate_rollback_failed"] = not bool((summary.get("model_gate_rollback") or {}).get("success"))
            else:
                summary["model_gate_rollback"] = None
                summary["model_gate_rollback_failed"] = False
            summary["success"] = summary["failed_tasks"] == 0 and not summary["maintenance_failed"] and not summary["model_gate_failed"]
            summary["finished_at"] = datetime.now().isoformat(timespec="seconds")
            status = "success" if summary["success"] else "failed"
            error = None
            if not summary["success"]:
                errors = []
                if summary["failed_tasks"]:
                    errors.append(f"{summary['failed_tasks']} automation task(s) failed")
                if summary["maintenance_failed"]:
                    errors.append("report stale marking failed")
                if summary["model_gate_failed"]:
                    errors.append("model change gate failed")
                if summary.get("model_gate_rollback_failed"):
                    errors.append("model change rollback failed")
                error = "; ".join(errors)
            self.foundation.finish_run(run_id, status=status, summary=summary, error=error)
            return {"success": summary["success"], "run_id": run_id, **summary}
        except Exception as exc:
            summary["success"] = False
            summary["error"] = str(exc)
            summary["finished_at"] = datetime.now().isoformat(timespec="seconds")
            self.foundation.finish_run(run_id, status="failed", summary=summary, error=str(exc))
            return {"success": False, "run_id": run_id, **summary}

    @staticmethod
    def _date_ranges_overlap(left_from: str, left_to: str, right_from: str, right_to: str) -> bool:
        return not (left_to < right_from or right_to < left_from)

    @staticmethod
    def _payload_int(payload: Dict[str, Any], *keys: str) -> int:
        total = 0
        for key in keys:
            try:
                total += int(payload.get(key) or 0)
            except (TypeError, ValueError):
                pass
        return total

    def _prior_task_results(self, summary: Dict[str, Any], task: AutomationTask) -> List[Dict[str, Any]]:
        matches: List[Dict[str, Any]] = []
        for item in summary.get("tasks") or []:
            prior = item.get("task") or {}
            if not prior:
                continue
            if self._date_ranges_overlap(
                str(prior.get("date_from") or ""),
                str(prior.get("date_to") or ""),
                task.date_from,
                task.date_to,
            ):
                matches.append(item)
        return matches

    def _prior_result_changed(self, summary: Dict[str, Any], task: AutomationTask) -> bool:
        for item in self._prior_task_results(summary, task):
            if not item.get("success") or item.get("skipped"):
                continue
            payload = item.get("payload") or {}
            if self._payload_int(
                payload,
                "rows_changed",
                "field_changes",
                "queued_revalidation",
                "lottery_results_inserted",
                "lottery_results_updated",
                "sqlite_changes",
                "updated",
                "inserted",
                "changed_reports",
                "prediction_rows",
                "saved",
            ) > 0:
                return True
        return False

    def _prior_learning_needed(self, summary: Dict[str, Any], task: AutomationTask) -> bool:
        if self._prior_result_changed(summary, task):
            return True
        for item in self._prior_task_results(summary, task):
            if not item.get("success") or item.get("skipped"):
                continue
            payload = item.get("payload") or {}
            prior_kind = str((item.get("task") or {}).get("kind") or payload.get("task") or "")
            if prior_kind == "analysis" and self._payload_int(payload, "analyzed", "targets") > 0:
                return True
            if prior_kind == "validation" and self._payload_int(payload, "validated") > 0:
                return True
            if prior_kind == "national_ou_gate" and self._payload_int(payload, "changed_reports", "prediction_rows") > 0:
                return True
            if prior_kind == "bqc_full_axis_gate" and self._payload_int(payload, "changed_reports", "prediction_rows") > 0:
                return True
            if prior_kind == "bqc_half_time_profile" and self._payload_int(payload, "saved_profiles", "saved_audits") > 0:
                return True
            if prior_kind == "bqc_full_time_axis" and self._payload_int(payload, "saved") > 0:
                return True
            if prior_kind == "handicap_margin_axis" and self._payload_int(payload, "saved") > 0:
                return True
            if prior_kind == "prediction_error_review" and self._payload_int(payload, "saved") > 0:
                return True
        return False

    @staticmethod
    def _skipped_task_result(task: AutomationTask, reason: str) -> Dict[str, Any]:
        payload = {"success": True, "task": task.kind, "skipped": True, "reason": reason}
        return {
            "task": asdict(task),
            "success": True,
            "skipped": True,
            "reason": reason,
            "payload": payload,
            "elapsed_seconds": 0,
        }

    def _skip_task_reason(self, task: AutomationTask, summary: Dict[str, Any], *, force: bool) -> Optional[str]:
        if force:
            return None
        if task.kind == "validation":
            if _has_action(task.action_counts, "validate"):
                return None
            if self._prior_result_changed(summary, task):
                return None
            return "skipped_validation_no_result_changes_after_audit"
        if task.kind == "learning":
            if _has_action(task.action_counts, "refresh_learning"):
                return None
            if self._prior_learning_needed(summary, task):
                return None
            return "skipped_learning_no_analysis_validation_or_result_changes"
        return None
    def _execute_task(
        self,
        task: AutomationTask,
        *,
        timeout_seconds: int,
        max_events: int,
        max_analysis: int,
        max_intelligence: int,
        max_validation_dates: int,
        fetch_live_ou: bool,
        network_intelligence: bool,
        national_ou_fact_table: str,
        bqc_profile_fact_table: str,
        league: str,
        trigger_source: str,
        force: bool,
    ) -> Dict[str, Any]:
        task_run_id = self.foundation.start_run(
            run_type=f"automation_{task.kind}",
            match_date=task.match_date,
            trigger_source=trigger_source,
            summary={"stage": "start", "task": asdict(task)},
        )
        cmd = [
            sys.executable,
            "-X",
            "utf8",
            str(ROOT / "scripts" / "run_automation_task.py"),
            "--task",
            task.kind,
            "--db",
            self.db_path,
            "--oddsfe-db",
            self.oddsfe_db_path,
            "--from",
            task.date_from,
            "--to",
            task.date_to,
            "--max-events",
            str(max_events),
            "--max-analysis",
            str(max_analysis),
            "--max-intelligence",
            str(max_intelligence),
            "--max-validation-dates",
            str(max_validation_dates),
            "--trigger-source",
            trigger_source,
            "--national-ou-fact-table",
            national_ou_fact_table,
            "--bqc-profile-fact-table",
            bqc_profile_fact_table,
        ]
        if league:
            cmd.extend(["--league", league])
        if fetch_live_ou:
            cmd.append("--fetch-live-ou")
        if network_intelligence:
            cmd.append("--network-intelligence")
        if force:
            cmd.append("--force")

        started = time.time()
        base = {"task": asdict(task), "run_id": task_run_id, "cmd": " ".join(cmd)}
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(ROOT),
                env=None,
                text=True,
                encoding="utf-8",
                errors="replace",
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=max(30, int(timeout_seconds)),
            )
            elapsed = round(time.time() - started, 1)
            output = proc.stdout or ""
            payload = _parse_task_payload(output)
            success = proc.returncode == 0 and payload.get("success") is not False
            result = {
                **base,
                "success": success,
                "skipped": bool(payload.get("skipped")),
                "reason": payload.get("reason") if payload.get("skipped") else None,
                "exit_code": proc.returncode,
                "elapsed_seconds": elapsed,
                "payload": payload,
                "output_tail": output[-4000:],
            }
            self.foundation.finish_run(task_run_id, status="success" if success else "failed", summary=result, error=None if success else payload.get("error") or payload.get("parse_error"))
            return result
        except subprocess.TimeoutExpired as exc:
            elapsed = round(time.time() - started, 1)
            output = exc.stdout if isinstance(exc.stdout, str) else ""
            result = {
                **base,
                "success": False,
                "timeout": True,
                "elapsed_seconds": elapsed,
                "output_tail": (output or "")[-4000:],
            }
            self.foundation.finish_run(task_run_id, status="failed", summary=result, error="timeout")
            return result
        except Exception as exc:
            elapsed = round(time.time() - started, 1)
            result = {**base, "success": False, "elapsed_seconds": elapsed, "error": str(exc)}
            self.foundation.finish_run(task_run_id, status="failed", summary=result, error=str(exc))
            return result




